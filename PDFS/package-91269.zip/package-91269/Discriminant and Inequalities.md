#L2MAEL 

---

Discriminant is from the quadratic equation.
$$x=\frac{-b\pm\sqrt{b^2-4ac}}{2a}$$
The $b^2-4ac$ part; that is the discriminant. 

---

**The number of the discriminant (below zero, zero, or above zero) represent the number of intersections along the x-axis.**

If the discriminant is below zero, there is no real solution(s).
If the discriminant is zero, there is one real solution.
If the discriminant is above zero, there is two real solutions.
	"*Solutions*" mean the number of intersections along the $x$-axis.

### Examples with the $x$-axis can be seen below:
#### if $b^2-4ac < 0 =$ No Real Solution(s)
<img src="img/62fa23fd5b4b379b7026fe045af3fd11.png" style='width: 300px;' />

#### if $b^2-4ac > 0 =$ Two Real Solutions
<img src="img/0a2004e22dd9cf16ece86ed29fe593fa.png" style='width: 300px;' />

#### if $b^2-4ac = 0 =$ One Real Solution
<img src="img/d18c62f62b3572c4d42023253c4ba716.png" style='width: 300px;' />

However, this doesn't just apply to the $x$-intercepts. This same concept can be applied when you use two graphs -- a linear and a non-linear.
When using simultaneous equation to combine both equations to turn it into a '<u>single</u> **quadratic**' equation, you can do the same thing.

---
## <u>Inequalities:</u>
Now, why is this important? This is used in contexts like below:
<img src="img/96132d49da6fbd338fd08eb0c48c1155.png" style='width: 500px;' />
$$y=\left(x-6\right)^{2}+3$$
$$y=-\left(x-6\right)^{2}-4$$
$$y=kx+1$$
Where you're asked to find the suitable values for $a$ (linear line(third graph)), so that the line does not touch either parabolas.
Follow the steps below:
1. use simultaneous equation to combine both equations to turn it into a '<u>single</u> **quadratic**' equation
2. substitute the values of $a,b,c$ from the quadratic equation, into the discriminant $(b^2-4ac=0)$ (keep the sign as $=$, as inequality signs are not supposed to go here)
3. find the value(s) of the unknown variable (this case, it's $k$)
4. use inequality to figure out the possible range:

***Step Four Explained:***
After calculating the values for $k$, I put them in a graph for easier view:

<img src="img/3025d8645a6b9786ff9109dfccd47015.png" style='width: 500px;' />

This indicates that the yellow zone representing $k$ is between the numbers $-24.32$, and $0.33$. 
The inequality for $k$ would be: $-24.32<k<0.33$.
This inequality means that the linear line wouldn't intersect the top parabola as long as $k$ is between these two numbers (boundaries).

If discriminant is above zero, there would be two inequalities:
for example:
$k<-24.32$
$k>0.33$

This is possible, as sometimes the question is about finding the range where the line intersects twice. 
If it the discriminant is one, you do not need to create that parabola graph. You can just solve the equation, as $D=0$ straight away.

<u>Model Answer for top parabola & linear line:</u>
$$y=kx+1$$
$$y=(x-6)^2+3$$
$$kx+1=(x-6)^2+3$$
$$kx-2=(x-6)^2$$
$$kx-2=x^2-12x+36$$
$$x^2-12x-kx+36+2=0$$
$$x^2+(-12-k)x+38=0$$
$$a=1, \space\space\space b=-k-12, \space\space\space c=38$$
	Discriminant:
$$(-k-12)^2-4(1)(38)=0$$
$$k^2+24k+144-152=0$$
$$k^2+24k-8=0$$
$$k=0.33, or -24.32$$
	Since Discriminant must be below zero to have no intersections:

<img src="img/3025d8645a6b9786ff9109dfccd47015.png" style='width: 500px;' />
$$-24.32<k<0.33$$
[+], you must link this to the context of the question that's given. For example, if the question was asking you to find the range where the hose does not intersect the garden, you would have to say:

"For the hose to not touch the garden at all, the variable $k$, would have be between $-24.32$ and $0.33$."

---

Speaking from experience, to get better at *this* standard, doing questions over and over until it becomes a habit is necessary.