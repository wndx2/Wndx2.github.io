#L2MAEL 

---
## <u>Simultaneous Equations:</u>
Although you would've learnt this in L1 (hopefully), this is a quick breakdown:
First Equation:
$$2x-y=7$$
Second Equation:
$$3x+y=13$$
Solving:
*turning second equation into $y=$ form:*
$$y=-3x+13$$
*substituting into first equation:*
$$2x--3x+13=7$$

Solve for $x$, then, substitute that $x$ into the equation witih $y$.