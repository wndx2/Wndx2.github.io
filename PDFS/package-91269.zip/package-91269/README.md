
---

Heya! 👋

If you're reading this, you're probably one of the nerdy people who downloaded our "Vault." Before you start, **please read all of the following.**

1. **Use Obsidian for the Best Experience**
    You are strongly advised to open this Vault using [Obsidian.md](https://obsidian.md) -- it’s free and available on all major devices.
    The notes are written using Obsidian's Markdown system, and may not display properly elsewhere.
    
    Import the 'package-{sn}' to your pre-existing/new vault's directory, then you should see all of the Vault.
	
	For the theme, I personally recommend using my theme (because why not). My theme can be found in the link below:
	https://github.com/Wndx2/wndxTheme

2. **License and Usage Notice**
	 'This' Vault is provided **free of charge** (as of 1st of April 2025)
	By downloading and/or accessing 'this' Vault, you **automatically agree** to the terms outlined in our [[LICENSE]] (found inside the Vault).
    Any violation of the LICENSE terms may lead to actions such as:
        - A DMCA Takedown Notice
        - A Copyright Infringement Claim/Notice
        - Potential legal notices

3. **Academic Reminder**
    - We know that some people may be creating **prep sheets for exams**.
    - Please **do not copy-paste** entire pages directly into your prep sheets -- especially if you're at the same school as wndud.
    - Writing down **just formula(s)** is usually fine, but copy pasting large parts may cause issues with exam administrators (because everyone has the same cheat sheets) and could get some of you in trouble.
    Always **reword and personalize** your notes when possible!

4. **Need help?**
	Please visit our Discord server. We provide feedback when possible. 
	You also might meet fellow students later on.
	
	Plus, this is the only place you get to download our notes *legally*. 
	https://discord.gg/CPHVqbewtf

---
