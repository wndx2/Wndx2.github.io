
---

```markdown
Restricted Use License

Copyright (c) 박주영 (wndx2, sleepywndud). All rights Reserved.

For the purposes of this License, the term "Vault" refers to all contents 
contained within the directory, including but not limited to note(s), 
code(s) diagram(s), image(s), file(s), folder(s), subdirectory(ies), 
metadata(s), and any other associated material(s).

Permission is hereby granted to any individual obtaining a copy of this 
Vault and its accompanying documentation (collectively, the "Vault") to 
view and study the Vault solely for personal, educational, or evaluative 
purposes, subject to the following conditions:

- The Vault may not be used, copied, modified, merged, published, 
  distributed, sublicensed, sold, or otherwise exploited, in whole or in 
  part, for any private, commercial, non-commercial, academic, or public 
  purpose without the prior express written consent of the copyright 
  holder(s).
- Any unauthorized use, reproduction, or distribution of the Vault, in 
  whole or in part, is strictly prohibited.

The Vault is provided "as is", without warranty of any kind, express or 
implied, including but not limited to warranties of merchantability, 
fitness for a particular purpose, and noninfringement. In no event shall 
the authors or copyright holders be liable for any claim, damages, or 
other liability, whether in an action of contract, tort, or otherwise, 
arising from, out of, or in connection with the Vault or the use of or 
other dealings in the Vault.
```

